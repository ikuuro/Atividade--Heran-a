/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.imovel;

/**
 *
 * @author ikaro
 */
public class imovelVelho extends Imovel {
     

    public void imprimirValor() {
        System.out.println("o imovel é velho");
    }
    
}
